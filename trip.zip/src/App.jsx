export default function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-7xl w-full">
        
        {/* Columna 1 - Comunidad */}
        <div className="bg-slate-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold flex items-center gap-2 mb-4">
            <span>⭐</span> Ingreso a la Comunidad y Clases
          </h2>
          <p className="mb-2">
            <strong>Ingreso a la Comunidad</strong><br />
            Aporte consciente desde $1.000
          </p>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Acceso a la comunidad en Telegram</li>
            <li>Acceso a tutoriales en YouTube</li>
          </ul>
          <p className="italic text-sm mb-4">
            No incluye clases, transmisiones ni grabaciones
          </p>
          <p className="mb-2"><strong>Clase Unitaria:</strong> $6.000</p>
          <p><strong>Clase Recreativa:</strong> $3.000<br />1 hora de práctica los fines de semana</p>
        </div>

        {/* Columna 2 - Planes */}
        <div className="bg-slate-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold flex items-center gap-2 mb-4">
            <span>⭐</span> Planes de Suscripción a la Escuela
          </h2>
          
          <p className="mb-2 font-semibold">Plan de Entrada — $10.000</p>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>1 clase al mes</li>
            <li>Acceso a la plataforma educativa</li>
            <li>Acceso a la comunidad en Telegram</li>
            <li>Clases extra a $5.000</li>
          </ul>

          <p className="mb-2 font-semibold">Plan Básico — $30.000</p>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Hasta 6 clases al mes</li>
            <li>Acceso a la plataforma educativa</li>
            <li>Acceso a la comunidad en Telegram</li>
            <li>Actividades recreativas en entornos naturales</li>
            <li>Acceso al Grupo de Estudio Avanzado con un aporte adicional de $5.000</li>
          </ul>

          <p className="mb-2 font-semibold">Plan Completo — $40.000</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Hasta 12 clases al mes</li>
            <li>Acceso a la plataforma educativa</li>
            <li>Acceso a la comunidad en Telegram</li>
            <li>Actividades recreativas en entornos naturales</li>
            <li>Transmisiones online y grabaciones</li>
            <li>Acceso al Grupo de Estudio Avanzado (Psicoanálisis, Taoísmo, Medicina China)</li>
          </ul>
        </div>

        {/* Columna 3 - Servicio */}
        <div className="bg-slate-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold flex items-center gap-2 mb-4">
            <span>⭐</span> Servicio Personalizado de Entrenamiento
          </h2>

          <p className="mb-2"><strong>Valor tomando una suscripción:</strong> $10.000</p>
          <p className="mb-4"><strong>Valor consulta independiente (sin suscripción):</strong> $15.000</p>
          <p className="mb-4"><strong>Duración:</strong> 1 hora</p>

          <p className="mb-4">
            <strong>Acceso adicional:</strong> En la versión sin suscripción, este servicio da acceso a 1 clase de Tai Chi dentro de las posibilidades del mes.
          </p>

          <h3 className="font-semibold mb-2">Objetivos de la sesión</h3>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Definir el deseo o meta de la persona con respecto a la práctica</li>
            <li>Entregar herramientas teóricas y prácticas</li>
            <li>Definir una rutina de entrenamiento semanal</li>
            <li>Identificar y desarmar asociaciones mentales que bloqueen el avance</li>
          </ul>

          <h3 className="font-semibold mb-2">Temas principales de trabajo</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>Herramientas de autoconocimiento</li>
            <li>Herramientas psicoanalíticas</li>
            <li>Herramientas de magia</li>
            <li>La importancia de la generación del hábito</li>
            <li>La importancia de la meditación</li>
          </ul>
        </div>

      </div>
    </div>
  )
}
